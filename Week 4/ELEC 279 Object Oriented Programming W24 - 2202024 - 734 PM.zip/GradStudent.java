package InheretancePackage;

public class GradStudent extends Student {
	
	public GradStudent() {}

}
